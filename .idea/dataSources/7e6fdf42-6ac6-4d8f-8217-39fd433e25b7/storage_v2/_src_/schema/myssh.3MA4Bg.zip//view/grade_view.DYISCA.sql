create view grade_view as
  select
    `g`.`stuaccount` AS `stuaccount`,
    `s`.`stuname`    AS `stuname`,
    `c`.`classname`  AS `classname`,
    `g`.`lasttime`   AS `lasttime`,
    `g`.`times`      AS `times`,
    `g`.`grade`      AS `grade`
  from `myssh`.`studentinfo` `s`
    join `myssh`.`courseinfo` `c`
    join `myssh`.`gradeinfo` `g`
  where ((`g`.`stuaccount` = `s`.`stuaccount`) and (`g`.`classid` = `c`.`classid`));

