create trigger update_name
  after UPDATE
  on studentinfo
  for each row
  BEGIN UPDATE healthinfo SET stuname = NEW.stuname WHERE stuaccount = NEW.stuaccount;END;

