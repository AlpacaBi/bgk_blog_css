create trigger license_stu
  after INSERT
  on licenseinfo
  for each row
  BEGIN UPDATE studentInfo SET leave_time=NEW.recv_time, scondition = '??ҵ' WHERE stuaccount = NEW.stuaccount; END;

